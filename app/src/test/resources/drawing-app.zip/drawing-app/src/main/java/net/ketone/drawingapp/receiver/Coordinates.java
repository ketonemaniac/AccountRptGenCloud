package net.ketone.drawingapp.receiver;

public class Coordinates {

    private int x;
    private int y;
    private char pattern;

    public Coordinates(int x, int y, char pattern) {
        this.x = x;
        this.y = y;
        this.pattern = pattern;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public char getPattern() {
        return pattern;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Coordinates that = (Coordinates) o;

        if (x != that.x) return false;
        if (y != that.y) return false;
        return pattern == that.pattern;
    }

    @Override
    public int hashCode() {
        int result = x;
        result = 31 * result + y;
        result = 31 * result + (int) pattern;
        return result;
    }

    @Override
    public String toString() {
        return "Coordinates x=" + x + " y=" + y + " pattern=" + pattern;
    }
}
