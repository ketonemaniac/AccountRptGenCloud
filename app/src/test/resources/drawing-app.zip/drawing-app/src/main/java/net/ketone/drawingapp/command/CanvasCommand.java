package net.ketone.drawingapp.command;

import net.ketone.drawingapp.receiver.ICanvas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;

@Component
@Scope("prototype")
public class CanvasCommand implements Command {

    @Autowired
    private ICanvas canvas;

    private int width;
    private int height;

    public CanvasCommand(List<String> args) throws CommandException {
        if(args.size() != 3) {
            throw new CommandException("Canvas Command usage: C [width] [height]");
        }
        try {
            this.width = Integer.parseInt(args.get(1));
            this.height = Integer.parseInt(args.get(2));
        } catch (Exception e) {
            throw new CommandException("Canvas Command usage: C [width] [height]");
        }
    }

    @PostConstruct
    public void init() throws CommandException {
        if(width <= 0 || height <= 0) {
            throw new CommandException("Canvas cannot have zero or negative width/height.");
        }
    }

    @Override
    public void execute() {
        canvas.createCanvas(width, height);
    }

}
