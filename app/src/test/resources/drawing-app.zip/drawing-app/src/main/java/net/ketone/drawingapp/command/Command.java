package net.ketone.drawingapp.command;

/**
 * Commands to perform actions on Canvas
 */
public interface Command {

    void execute();
}
