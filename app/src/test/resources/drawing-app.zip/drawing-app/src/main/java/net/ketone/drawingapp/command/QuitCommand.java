package net.ketone.drawingapp.command;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Scope("prototype")
public class QuitCommand implements Command {

    public QuitCommand(List<String> args) throws CommandException {
        super();
    }

    @Override
    public void execute() {
        System.exit(0);
    }
}
