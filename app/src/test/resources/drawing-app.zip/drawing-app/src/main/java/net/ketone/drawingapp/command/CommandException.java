package net.ketone.drawingapp.command;

/**
 * Exceptions thrown by Commands
 */
public class CommandException extends Exception {

    public CommandException(String msg) {
        super(msg);
    }

}
