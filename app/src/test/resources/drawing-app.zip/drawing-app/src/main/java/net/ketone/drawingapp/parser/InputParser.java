package net.ketone.drawingapp.parser;

import net.ketone.drawingapp.command.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

/**
 * Factory class to create Commands based on inputs
 */
@Component
public class InputParser {

    @Autowired
    private ApplicationContext ctx;

    private final Map<String, Class<? extends Command>> commands = new HashMap<>();

    @PostConstruct
    public void initialize() {
        commands.put("C", CanvasCommand.class);
        commands.put("Q", QuitCommand.class);
        commands.put("L", LineCommand.class);
        commands.put("R", RectangleCommand.class);
        commands.put("B", BucketFillCommand.class);
    }

    public Command parse(Scanner scanner, PrintWriter output) {
        try {
            return readIn(scanner, output);
        } catch (Exception e) {
            // e.printStackTrace();
            output.println("An error occurred: " + getRootCause(e).getMessage());
        } finally {
            output.flush();
        }
        return null;
    }

    private Command readIn(Scanner scanner, PrintWriter output) throws IOException {
        String nextInput = scanner.nextLine();
        List<String> args = Arrays.asList(nextInput.split(" "));
        Class commandClass = commands.get(args.get(0));
        if(commandClass != null) {
            return (Command) ctx.getBean(commandClass, args);
        } else {
            output.println("invalid command.");
            output.flush();
        }
        return null;
    }

    private Throwable getRootCause(Throwable e) {
        Throwable rootCause = e;
        while(rootCause.getCause() != null) {
            rootCause = rootCause.getCause();
        }
        return rootCause;
    }
}
