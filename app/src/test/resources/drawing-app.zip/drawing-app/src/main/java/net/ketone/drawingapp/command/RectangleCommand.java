package net.ketone.drawingapp.command;

import net.ketone.drawingapp.receiver.Coordinates;
import net.ketone.drawingapp.receiver.ICanvas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

@Component
@Scope("prototype")
public class RectangleCommand implements Command {

    @Autowired
    private ICanvas canvas;

    private int x1, x2, y1, y2;

    public RectangleCommand(List<String> args) throws CommandException {
        if(args.size() != 5) {
            throw new CommandException("Rectangle Command usage: R [x1] [y1] [x2] [y2]");
        }
        try {
            this.x1 = Integer.parseInt(args.get(1))-1;
            this.y1 = Integer.parseInt(args.get(2))-1;
            this.x2 = Integer.parseInt(args.get(3))-1;
            this.y2 = Integer.parseInt(args.get(4))-1;
        } catch (Exception e) {
            throw new CommandException("Rectangle Command usage: R [x1] [y1] [x2] [y2]");
        }
    }

    @PostConstruct
    public void init() throws CommandException {
        if(!canvas.isInitialized()) {
            throw new CommandException("Please create the canvas first.");
        }
        if(x1 < 0 || x2 < 0 || y1 < 0 || y2 < 0
                || x1 >= canvas.getWidth() || x2 >= canvas.getWidth() || y1 >= canvas.getHeight() || y2 >= canvas.getHeight()) {
            throw new CommandException("Specified coordinates is out of canvas bounds.");
        }
    }

    @Override
    public void execute() {
        List<Coordinates> coords = new ArrayList<>();
        int minx = Math.min(x1, x2), maxx = Math.max(x1, x2),
                miny = Math.min(y1, y2), maxy = Math.max(y1, y2);
        for(int i = minx; i <= maxx; i++) {
            for(int j = miny; j <= maxy; j++) {
                if(i == minx || i == maxx) {
                    coords.add(new Coordinates(i, j, 'x'));
                } else if(j == miny || j == maxy) {
                    coords.add(new Coordinates(i, j, 'x'));
                }
            }
        }
        canvas.addShape(coords);
    }
}
