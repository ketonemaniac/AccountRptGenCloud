package net.ketone.drawingapp.receiver;

import org.springframework.stereotype.Component;

import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

@Component
public class Canvas implements ICanvas {

    private char [][] board;
    private int width, height;

    // doubly linked list, so you could undo shape operations if necessary without affecting other shapes
    private Deque<List<Coordinates>> shapes;

    @Override
    public void createCanvas(int width, int height) {
        this.width = width;
        this.height = height;
        board = new char[height][width];
        // initialize
        for(int i = 0; i < height; i++) {
            for(int j = 0; j < width; j++) {
                board[i][j] = ' ';
            }
        }
        shapes = new LinkedList<>();
    }

    @Override
    public void addShape(List<Coordinates> coords) {
        // TODO: do verification
        shapes.add(coords);
        render();
    }

    @Override
    public boolean isInitialized() {
        return board != null;
    }

    private void render() {
        for(List<Coordinates> shape : shapes) {
            for(Coordinates coord : shape) {
                board[coord.getY()][coord.getX()] = coord.getPattern();
            }
        }
    }

    @Override
    public String printCanvas() {
        StringBuilder sb = new StringBuilder("-");
        for(int i = 0; i < width; i++) {
            sb.append("-");
        }
        sb.append("-");
        sb.append(System.lineSeparator());
        for(int j = 0; j < height; j++) {
            sb.append("|");
            for(int i = 0; i < width; i++) {
                sb.append(board[j][i]);
            }
            sb.append("|");
            sb.append(System.lineSeparator());
        }
        sb.append("-");
        for(int i = 0; i < width; i++) {
            sb.append("-");
        }
        sb.append("-");
        return sb.toString();
    }

    @Override
    public Character charAt(int x, int y) {
        if(x < 0 || y < 0 || x >= width || y >= height) {
            return null;
        }
        return board[y][x];
    }

    @Override
    public int getWidth() {
        return width;
    }

    @Override
    public int getHeight() {
        return height;
    }

}
