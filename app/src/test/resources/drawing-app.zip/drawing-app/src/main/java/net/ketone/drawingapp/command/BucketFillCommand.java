package net.ketone.drawingapp.command;

import net.ketone.drawingapp.receiver.Coordinates;
import net.ketone.drawingapp.receiver.ICanvas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.*;

@Component
@Scope("prototype")
public class BucketFillCommand implements Command {

    @Autowired
    private ICanvas canvas;

    private int x, y;
    private char fillChar;
    private char originalChar;
    private Set<Coordinates> visitedCoordinates = new HashSet<>();


    public BucketFillCommand(List<String> args) throws CommandException {
        if(args.size() != 4) {
            throw new CommandException("Bucket Fill Command usage: B [x] [y] [fillChar]");
        }
        try {
            this.x = Integer.parseInt(args.get(1))-1;
            this.y = Integer.parseInt(args.get(2))-1;
            this.fillChar = args.get(3).charAt(0);
        } catch (Exception e) {
            throw new CommandException("Bucket Fill Command usage: B [x] [y] [fillChar]");
        }
    }

    @PostConstruct
    public void init() throws CommandException {
        if(!canvas.isInitialized()) {
            throw new CommandException("Please create the canvas first.");
        }
        if(x < 0 || y < 0
                || x >= canvas.getWidth() || y >= canvas.getHeight()) {
            throw new CommandException("Specified coordinates is out of canvas bounds.");
        }

    }

    @Override
    public void execute() {
        List<Coordinates> coords = new ArrayList<>();
        originalChar = canvas.charAt(x, y);
        doFill(coords, new Coordinates(x, y, fillChar));
        canvas.addShape(coords);
    }

    private void doFill(List<Coordinates> coords, Coordinates coordinates) {
        if(visitedCoordinates.contains(coordinates)) return;
        Character c = canvas.charAt(coordinates.getX(), coordinates.getY());
        if(c != null && c == originalChar) {
            coords.add(coordinates);
            visitedCoordinates.add(coordinates);
            // at the 4 surrounding places to queue
            doFill(coords, new Coordinates(coordinates.getX(), coordinates.getY()-1, coordinates.getPattern()));
            doFill(coords, new Coordinates(coordinates.getX()-1, coordinates.getY(), coordinates.getPattern()));
            doFill(coords, new Coordinates(coordinates.getX()+1, coordinates.getY(), coordinates.getPattern()));
            doFill(coords, new Coordinates(coordinates.getX(), coordinates.getY()+1, coordinates.getPattern()));
        }

    }
}
