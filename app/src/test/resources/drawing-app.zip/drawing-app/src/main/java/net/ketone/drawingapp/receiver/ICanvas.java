package net.ketone.drawingapp.receiver;

import java.util.List;

/**
 * Canvas interface. Since most invalid inputs are already dealt with by the commands,
 * callers to this interface as assumed to have good inputs.
 */
public interface ICanvas {

    /**
     * Creates canvas
     * @param width assumed positive
     * @param height assumed positive
     */
    void createCanvas(int width, int height);

    /**
     * A "shape" is basically a list of Coordinates to be overlayed on the Canvas
     * @param coords
     */
    void addShape(List<Coordinates> coords);

    /**
     * indicates whether a valid Canvas is already created or not
     * @return
     */
    boolean isInitialized();

    /**
     * String formatted canvas for output purposes
     * @return
     */
    String printCanvas();

    /**
     * current character at a particular canvas position
     * @param x
     * @param y
     * @return
     */
    Character charAt(int x, int y);

    int getWidth();

    int getHeight();
}
