package net.ketone.drawingapp;

import net.ketone.drawingapp.command.Command;
import net.ketone.drawingapp.parser.InputParser;
import net.ketone.drawingapp.receiver.Canvas;
import net.ketone.drawingapp.receiver.ICanvas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Entry point of application
 */
@SpringBootApplication
@Service
public class DrawingApplication {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(DrawingApplication.class, args);
		ctx.getBean(DrawingApplication.class).run(new Scanner(System.in), new PrintWriter(System.out));
	}

	@Autowired
	private InputParser parser;
	@Autowired
	private ICanvas canvas;

	public void run(Scanner scanner, PrintWriter printWriter) {
		printWriter.println("enter command: ");
		printWriter.flush();
		while(scanner.hasNextLine()) {
			Command c = parser.parse(scanner, printWriter);
			if(c != null) {
				try {
					c.execute();
				} catch (Exception e) {
					e.printStackTrace();	// unexpected exceptions...
				}
				printWriter.println(canvas.printCanvas());
				printWriter.println("enter command: ");
				printWriter.flush();
			}
		}

	}

}
