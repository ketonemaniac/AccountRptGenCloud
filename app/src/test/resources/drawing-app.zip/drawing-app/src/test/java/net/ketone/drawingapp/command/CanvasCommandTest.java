package net.ketone.drawingapp.command;

import net.ketone.drawingapp.matcher.RootCauseExceptionMatcher;
import net.ketone.drawingapp.receiver.ICanvas;
import org.hamcrest.Matchers;
import org.junit.Rule;
import org.junit.Test;
import org.junit.contrib.java.lang.system.ExpectedSystemExit;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;

import static org.mockito.ArgumentMatchers.eq;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes=CanvasCommand.class)
public class CanvasCommandTest {

    @MockBean
    private ICanvas canvas;
    @Autowired
    private ApplicationContext ctx;
	@Rule
	public final ExpectedException exception = ExpectedException.none();

    @Test
    public void testSuccessfulExecution() throws CommandException {
        Command command = ctx.getBean(CanvasCommand.class, Arrays.asList("C","2","3"));
        command.execute();
        Mockito.verify(canvas).createCanvas(eq(2), eq(3));
    }

    @Test
    public void testMissingArguments() throws CommandException {
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Canvas Command usage: C [width] [height]");
        Command command = ctx.getBean(CanvasCommand.class, Arrays.asList("C"));
        command.execute();
    }


    @Test
    public void testNonNumericArguments() throws CommandException {
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Canvas Command usage: C [width] [height]");
        Command command = ctx.getBean(CanvasCommand.class, Arrays.asList("C","a","b"));
        command.execute();
    }

    @Test
    public void testTooManyArguments() throws CommandException {
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Canvas Command usage: C [width] [height]");
        Command command = ctx.getBean(CanvasCommand.class, Arrays.asList("C","1","2","3"));
        command.execute();
    }

    @Test
    public void testNegativeArguments() throws CommandException {
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Canvas cannot have zero or negative width/height.");
        Command command = ctx.getBean(CanvasCommand.class, Arrays.asList("C","-1","0"));
        command.execute();
    }

}
