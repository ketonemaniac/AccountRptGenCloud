package net.ketone.drawingapp.command;

import net.ketone.drawingapp.matcher.RootCauseExceptionMatcher;
import net.ketone.drawingapp.receiver.Coordinates;
import net.ketone.drawingapp.receiver.ICanvas;
import org.hamcrest.Matchers;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.hamcrest.MockitoHamcrest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes=BucketFillCommand.class)
public class BucketFillCommandTest {

    @MockBean
    private ICanvas canvas;
    @Autowired
    private ApplicationContext ctx;
    @Rule
    public final ExpectedException exception = ExpectedException.none();

    private void initializeCanvas() {
        Mockito.when(canvas.isInitialized()).thenReturn(true);
        Mockito.when(canvas.getWidth()).thenReturn(5);
        Mockito.when(canvas.getHeight()).thenReturn(5);
    }

    /**
     * Fill in a cross like shape resursively from the middle to all 4 sides without overflowing to the corners
     * -------
     * | x x |
     * |xx xx|
     * |     |
     * |xx xx|
     * | x x |
     * -------
     * @throws CommandException
     */
    @Test
    public void testCasacadeFillEmptySpace() throws CommandException {
        initializeCanvas();
        int[][] xPoints = {{1,0},{3,0},{0,1},{1,1},{3,1},{4,1},
                {0,3},{1,3},{3,3},{4,3},{1,4},{3,4}};

        for(int i = 0; i < 5; i++) {
            for(int j = 0; j < 5; j++) {
                Mockito.when(canvas.charAt(eq(i), eq(j))).thenReturn(' ');    // default
            }
        }
        for(int[] point : xPoints) {
            Mockito.when(canvas.charAt(eq(point[0]), eq(point[1]))).thenReturn('x');
        }
        // fill center
        Command command = ctx.getBean(BucketFillCommand.class, Arrays.asList("B","3","3","o"));
        command.execute();
        List<Coordinates> coords = Arrays.asList(
                new Coordinates(2,0,'o'), new Coordinates(2,1,'o'),
                new Coordinates(0,2,'o'), new Coordinates(1,2,'o'),
                new Coordinates(2,2,'o'), new Coordinates(3,2,'o'),
                new Coordinates(4,2,'o'), new Coordinates(2,3,'o'),
                new Coordinates(2,4,'o')
                );
        Mockito.verify(canvas).addShape((List<Coordinates>) MockitoHamcrest.argThat(Matchers.containsInAnyOrder(coords.toArray())));
    }

    /**
     * Fill in a cross like shape resursively from the middle to all 4 sides without overflowing to the corners
     * -------
     * |  x  |
     * |  x  |
     * |xxxxx|
     * |  x  |
     * |  x  |
     * -------
     * @throws CommandException
     */
    @Test
    public void testCasacadeFillExistingSpace() throws CommandException {
        initializeCanvas();
        int[][] xPoints = {{2,0},{2,1},{0,2},{1,2},{2,2},{3,2},
                {4,2},{2,3},{2,4}};

        for(int i = 0; i < 5; i++) {
            for(int j = 0; j < 5; j++) {
                Mockito.when(canvas.charAt(eq(i), eq(j))).thenReturn(' ');    // default
            }
        }
        for(int[] point : xPoints) {
            Mockito.when(canvas.charAt(eq(point[0]), eq(point[1]))).thenReturn('x');
        }
        // fill center
        Command command = ctx.getBean(BucketFillCommand.class, Arrays.asList("B","3","3","o"));
        command.execute();
        List<Coordinates> coords = Arrays.asList(
                new Coordinates(2,0,'o'), new Coordinates(2,1,'o'),
                new Coordinates(0,2,'o'), new Coordinates(1,2,'o'),
                new Coordinates(2,2,'o'), new Coordinates(3,2,'o'),
                new Coordinates(4,2,'o'), new Coordinates(2,3,'o'),
                new Coordinates(2,4,'o')
        );
        Mockito.verify(canvas).addShape((List<Coordinates>) MockitoHamcrest.argThat(Matchers.containsInAnyOrder(coords.toArray())));
    }

   @Test
    public void testMissingArguments() throws CommandException {
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Bucket Fill Command usage: B [x] [y] [fillChar]");
        Command command = ctx.getBean(BucketFillCommand.class, Arrays.asList("B"));
        command.execute();
    }


    @Test
    public void testNonNumericArguments() throws CommandException {
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Bucket Fill Command usage: B [x] [y] [fillChar]");
        Command command = ctx.getBean(BucketFillCommand.class, Arrays.asList("B","a","b","c"));
        command.execute();
    }

    @Test
    public void testTooManyArguments() throws CommandException {
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Bucket Fill Command usage: B [x] [y] [fillChar]");
        Command command = ctx.getBean(BucketFillCommand.class, Arrays.asList("B","2","2","o","c"));
        command.execute();
    }

    @Test
    public void testCanvasNotReady() throws CommandException {
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Please create the canvas first.");
        Command command = ctx.getBean(BucketFillCommand.class, Arrays.asList("B","2","2","o"));
        command.execute();
    }

    @Test
    public void testOutOfBounds() throws CommandException {
        initializeCanvas();
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Specified coordinates is out of canvas bounds.");
        Command command = ctx.getBean(BucketFillCommand.class, Arrays.asList("B","0","0","o"));
        command.execute();
    }

 }

