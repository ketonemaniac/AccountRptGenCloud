package net.ketone.drawingapp.matcher;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;

/**
 * Matcher to find root cause of an Expected exception
 */
public class RootCauseExceptionMatcher extends BaseMatcher<Object> {
    private Class<? extends Throwable> clazz;

    public RootCauseExceptionMatcher(Class<? extends Throwable> clazz) {
        this.clazz = clazz;
    }

    @Override
    public boolean matches(Object item) {
        if(!(item instanceof Throwable))
            return false;
        Throwable e = (Throwable) item;
        while(e.getCause() != null) {
            e = e.getCause();
        }
        return clazz.isInstance(e);
    }

    @Override
    public void describeTo(Description descr) {
        descr.appendText("unexpected exception");
    }
}