package net.ketone.drawingapp.command;

import net.ketone.drawingapp.matcher.RootCauseExceptionMatcher;
import net.ketone.drawingapp.receiver.Coordinates;
import net.ketone.drawingapp.receiver.ICanvas;
import org.hamcrest.Matchers;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.hamcrest.MockitoHamcrest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.awt.*;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.eq;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes=RectangleCommand.class)
public class RectangleCommandTest {

    @MockBean
    private ICanvas canvas;
    @Autowired
    private ApplicationContext ctx;
    @Rule
    public final ExpectedException exception = ExpectedException.none();

    private void initializeCanvas() {
        Mockito.when(canvas.isInitialized()).thenReturn(true);
        Mockito.when(canvas.getWidth()).thenReturn(4);
        Mockito.when(canvas.getHeight()).thenReturn(4);
    }

    /**
     * Basically this is a dot
     * @throws CommandException
     */
    @Test
    public void testSmallestBox() throws CommandException {
        initializeCanvas();
        Command command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","1","1","1","1"));
        command.execute();
        List<Coordinates> coords = Arrays.asList(
                new Coordinates(0,0,'x')
        );
        Mockito.verify(canvas).addShape((List<Coordinates>) MockitoHamcrest.argThat(Matchers.containsInAnyOrder(coords.toArray())));
    }

    /**
     * rectangle with width=1, basically a line
     * @throws CommandException
     */
    @Test
    public void testVerticalLine() throws CommandException {
        initializeCanvas();
        Command command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","1","2","1","4"));
        command.execute();
        List<Coordinates> coords = Arrays.asList(
                new Coordinates(0,1,'x'),
                new Coordinates(0,2,'x'),
                new Coordinates(0,3,'x')
        );

        // the reverse should also be true
        command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","1","4","1","2"));
        command.execute();
        Mockito.verify(canvas, Mockito.times(2)).addShape((List<Coordinates>) MockitoHamcrest.argThat(Matchers.containsInAnyOrder(coords.toArray())));
    }

    /**
     * rectangle with height=1, basically a line
     * @throws CommandException
     */
    @Test
    public void testHorizontalLine() throws CommandException {
        initializeCanvas();
        Command command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","2","1","4","1"));
        command.execute();
        List<Coordinates> coords = Arrays.asList(
                new Coordinates(1,0,'x'),
                new Coordinates(2,0,'x'),
                new Coordinates(3,0,'x')
        );

        // the reverse should also be true
        command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","4","1","2","1"));
        command.execute();
        Mockito.verify(canvas, Mockito.times(2)).addShape((List<Coordinates>) MockitoHamcrest.argThat(Matchers.containsInAnyOrder(coords.toArray())));
    }



    @Test
    public void testRectangleWithNoCenterSpace() throws CommandException {
        initializeCanvas();
        Command command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","2","1","4","2"));
        command.execute();
        List<Coordinates> coords = Arrays.asList(
                new Coordinates(1,0,'x'),
                new Coordinates(2,0,'x'),
                new Coordinates(3,0,'x'),
                new Coordinates(1,1,'x'),
                new Coordinates(2,1,'x'),
                new Coordinates(3,1,'x')
        );

        // the reverse should also be true
        command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","4","2","2","1"));
        command.execute();

        Mockito.verify(canvas, Mockito.times(2)).addShape((List<Coordinates>) MockitoHamcrest.argThat(Matchers.containsInAnyOrder(coords.toArray())));
    }

    @Test
    public void testRectangleWithCenterSpace() throws CommandException {
        initializeCanvas();
        Command command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","2","1","4","3"));
        command.execute();
        List<Coordinates> coords = Arrays.asList(
                new Coordinates(1,0,'x'),
                new Coordinates(2,0,'x'),
                new Coordinates(3,0,'x'),
                new Coordinates(1,1,'x'),
                // there is no 2, 1
                new Coordinates(3,1,'x'),
                new Coordinates(1,2,'x'),
                new Coordinates(2,2,'x'),
                new Coordinates(3,2,'x')
        );

        // the reverse should also be true
        command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","4","3","2","1"));
        command.execute();

        Mockito.verify(canvas, Mockito.times(2)).addShape((List<Coordinates>) MockitoHamcrest.argThat(Matchers.containsInAnyOrder(coords.toArray())));
    }


    @Test
    public void testMissingArguments() throws CommandException {
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Rectangle Command usage: R [x1] [y1] [x2] [y2]");
        Command command = ctx.getBean(RectangleCommand.class, Arrays.asList("R"));
        command.execute();
    }


    @Test
    public void testNonNumericArguments() throws CommandException {
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Rectangle Command usage: R [x1] [y1] [x2] [y2]");
        Command command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","a","b","c","d"));
        command.execute();
    }

    @Test
    public void testTooManyArguments() throws CommandException {
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Rectangle Command usage: R [x1] [y1] [x2] [y2]");
        Command command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","1","2","3","4","5"));
        command.execute();
    }

    @Test
    public void testCanvasNotReady() throws CommandException {
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Please create the canvas first.");
        Command command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","4","3","2","1"));
        command.execute();
    }

    @Test
    public void testXOutOfUpperBounds() throws CommandException {
        initializeCanvas();
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Specified coordinates is out of canvas bounds.");
        Command command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","1","1","5","3"));
        command.execute();
    }

    @Test
    public void testXOutOfLowerBounds() throws CommandException {
        initializeCanvas();
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Specified coordinates is out of canvas bounds.");
        Command command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","0","1","3","3"));
        command.execute();
    }

    @Test
    public void testYOutOfUpperBounds() throws CommandException {
        initializeCanvas();
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Specified coordinates is out of canvas bounds.");
        Command command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","1","1","3","5"));
        command.execute();
    }

    @Test
    public void testYOutOfLowerBounds() throws CommandException {
        initializeCanvas();
        exception.expect(new RootCauseExceptionMatcher(CommandException.class));
        exception.expectMessage("Specified coordinates is out of canvas bounds.");
        Command command = ctx.getBean(RectangleCommand.class, Arrays.asList("R","1","0","3","3"));
        command.execute();
    }

}
