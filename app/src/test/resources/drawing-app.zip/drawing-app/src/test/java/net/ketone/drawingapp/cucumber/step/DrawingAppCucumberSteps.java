package net.ketone.drawingapp.cucumber.step;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.ketone.drawingapp.DrawingApplication;
import net.ketone.drawingapp.parser.InputParser;
import net.ketone.drawingapp.receiver.Canvas;
import net.ketone.drawingapp.receiver.Coordinates;
import net.ketone.drawingapp.receiver.ICanvas;
import org.assertj.core.api.Assertions;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.ByteArrayInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {DrawingApplication.class, InputParser.class, Canvas.class})
@ContextConfiguration
public class DrawingAppCucumberSteps {

    @Autowired
    private ApplicationContext ctx;
    @Autowired
    private DrawingApplication drawingApplication;
    @Autowired
    private ICanvas canvas;

    private StringBuilder commands;
    private int width, height;

    @Given("^canvas of size (\\d+) x (\\d+)$")
    public void canvas_of_size_x(int width, int height) throws Throwable {
        this.width = width;
        this.height = height;
        System.out.println("givenCanvasOfSize " + width + " " + height);
        commands = new StringBuilder();
        commands.append("C ").append(width).append(" ").append(height).append(System.lineSeparator());
    }

    @When("^user creates a canvas$")
    public void user_creates_a_canvas() throws Throwable {
        ByteArrayInputStream in = new ByteArrayInputStream(commands.toString().getBytes());
        drawingApplication.run(new Scanner(in), new PrintWriter(System.out));
    }

    @Then("^canvas creation (.*) with dimensions (\\d+) x (\\d+)$")
    public void canvas_creation_with_dimensions_x(String result, int width, int height) throws Throwable {
        if("fails".equalsIgnoreCase(result)) {
            Assertions.assertThat(canvas.isInitialized()).isFalse();
        } else {
            Assertions.assertThat(canvas.isInitialized()).isTrue();
            Assertions.assertThat(canvas.getWidth()).isEqualTo(width);
            Assertions.assertThat(canvas.getHeight()).isEqualTo(height);
        }
    }

    @When("^user draws the following lines$")
    public void user_draws_the_following_lines(List<Map<String, String>> data) throws Throwable {
        for(Map<String, String> line : data) {
            commands.append("L ").append(line.get("x1")).append(" ")
                    .append(line.get("y1")).append(" ")
                    .append(line.get("x2")).append(" ")
                    .append(line.get("y2")).append(System.lineSeparator());
        }
        ByteArrayInputStream in = new ByteArrayInputStream(commands.toString().getBytes());
        drawingApplication.run(new Scanner(in), new PrintWriter(System.out));
    }

    @When("^user draws the following rectangles$")
    public void user_draws_the_following_rectangles(List<Map<String, String>> data) throws Throwable {
        for(Map<String, String> line : data) {
            commands.append("R ").append(line.get("x1")).append(" ")
                    .append(line.get("y1")).append(" ")
                    .append(line.get("x2")).append(" ")
                    .append(line.get("y2")).append(System.lineSeparator());
        }
        ByteArrayInputStream in = new ByteArrayInputStream(commands.toString().getBytes());
        drawingApplication.run(new Scanner(in), new PrintWriter(System.out));
    }

    @When("^user bucket fills with the following coordinates and pattern$")
    public void user_bucket_fills_with_the_following_coordinates_and_pattern(List<Map<String, String>> data) throws Throwable {
        for(Map<String, String> line : data) {
            commands.append("B ").append(line.get("x")).append(" ")
                    .append(line.get("y")).append(" ")
                    .append(line.get("pattern")).append(System.lineSeparator());
        }
        ByteArrayInputStream in = new ByteArrayInputStream(commands.toString().getBytes());
        drawingApplication.run(new Scanner(in), new PrintWriter(System.out));
    }

        @Then("^the canvas has the following coordinates marked$")
    public void the_canvas_has_the_following_coordinates_marked_with_x(List<List<String>> data) throws Throwable {
        List<Coordinates> coordinatesList = new ArrayList<>();
        for(int y = 0; y < height; y++) {
            for(int x = 0; x < width; x++) {
                char expected = data.get(y).get(x).length() == 0 ? ' ' : data.get(y).get(x).charAt(0);
                Assertions.assertThat(x + " " + y + " " + canvas.charAt(x, y)).isEqualTo(x + " " + y + " " + expected);
            }
        }
    }

}
