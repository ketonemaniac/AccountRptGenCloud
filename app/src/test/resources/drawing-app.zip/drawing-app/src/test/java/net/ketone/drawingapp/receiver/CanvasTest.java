package net.ketone.drawingapp.receiver;

import net.ketone.drawingapp.command.CanvasCommand;
import net.ketone.drawingapp.command.CommandException;
import net.ketone.drawingapp.matcher.RootCauseExceptionMatcher;
import org.assertj.core.util.Lists;
import org.assertj.core.util.Sets;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes=Canvas.class)
public class CanvasTest {

    @Autowired
    private ICanvas canvas;
    @Rule
    public final ExpectedException exception = ExpectedException.none();

    @Test
    public void testCanvasWithPositiveSize() {
        for(int i = 1; i <= 2; i++) {
            canvas.createCanvas(i, i);
            String output = canvas.printCanvas();
            String [] lines = output.split(System.lineSeparator());
            assertThat(lines.length).isEqualTo(i+2);   // contents + top and bottom lines

            // top and bottom borders
            assertThat(lines[0].toCharArray()).containsOnly('-');
            assertThat(lines[lines.length-1].toCharArray()).containsOnly('-');

            // centre strip
            for(int j = 1; j < lines.length-1; j++) {
                assertThat(lines[j].charAt(0)).isEqualTo('|');
                assertThat(lines[j].charAt(lines[j].length()-1)).isEqualTo('|');
                for(int k = 1; k < lines[j].length()-1; k++) {
                    assertThat(lines[j].charAt(k)).isEqualTo(' ');
                }
            }
        }
    }

    @Test
    public void testAddAndFetchOverlappingShapes() {
        canvas.createCanvas(3, 1);
        canvas.addShape(Arrays.asList(new Coordinates(0,0,'x'), new Coordinates(1,0,'x')));
        canvas.addShape(Arrays.asList(new Coordinates(1,0,'o')));
        String output = canvas.printCanvas();
        // should be xo[blank]
        String contentLine = output.split(System.lineSeparator())[1];
        assertThat(contentLine.substring(1,contentLine.length()-1)).isEqualTo("xo ");
        assertThat(canvas.charAt(0,0)).isEqualTo('x');
        assertThat(canvas.charAt(1,0)).isEqualTo('o');
        assertThat(canvas.charAt(2,0)).isEqualTo(' ');
    }

    @Test
    public void testGetWidthHeightInitialized() {
        canvas.createCanvas(2, 3);
        assertThat(canvas.getWidth()).isEqualTo(2);
        assertThat(canvas.getHeight()).isEqualTo(3);
        assertThat(canvas.isInitialized()).isTrue();
    }

}

