package net.ketone.drawingapp.parser;

import net.ketone.drawingapp.command.*;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.contrib.java.lang.system.ExpectedSystemExit;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.ByteArrayInputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

/**
 * Tests creation of different commands
 * Note that this is independent from whether the command is successfully executed or not
 */
@RunWith(SpringRunner.class)
//@SpringBootTest
public class InputParserTest {

	// the trick is NOT to create this as a bean -- otherwise the ctx will be the real one
	// and the commands will get exectured (not unit test)
	private InputParser inputParser;
	@Mock
	private ApplicationContext ctx;

	private StringWriter output;

	@Before
	public void init() throws NoSuchFieldException, IllegalAccessException {
		inputParser = new InputParser();
		inputParser.initialize();
		Field f = inputParser.getClass().getDeclaredField("ctx");
		f.setAccessible(true);
		f.set(inputParser, ctx);
	}


	private Command runInput(String cmd) {
		String input = cmd + System.lineSeparator();
		ByteArrayInputStream in = new ByteArrayInputStream(input.getBytes());
		output = new StringWriter();
		return inputParser.parse(new Scanner(in), new PrintWriter(output));
	}


	@Test
	public void testCreateCanvas() {
		runInput("C 2 3");
		Mockito.verify(ctx).getBean(eq(CanvasCommand.class), eq(Arrays.asList("C","2","3")));
	}

	@Test
	public void testLineCommand() {
		runInput("L 1 2 6 2");
		Mockito.verify(ctx).getBean(eq(LineCommand.class), eq(Arrays.asList("L","1","2","6","2")));
	}

	@Test
	public void testRectangleCommand() {
		runInput("R 14 1 18 3");
		Mockito.verify(ctx).getBean(eq(RectangleCommand.class), eq(Arrays.asList("R","14","1","18","3")));
	}

	@Test
	public void testBucketFillCommand() {
		runInput("B 10 3 o");
		Mockito.verify(ctx).getBean(eq(BucketFillCommand.class), eq(Arrays.asList("B","10","3","o")));
	}

	@Test
	public void testQuit() {
		runInput("Q");
		Mockito.verify(ctx).getBean(eq(QuitCommand.class), eq(Arrays.asList("Q")));
	}

	@Test
	public void testInvalidCommand() {
		runInput("X");
		Mockito.verifyZeroInteractions(ctx);
		Assertions.assertThat(output.toString()).contains("invalid command.");
	}


}