package net.ketone.drawingapp.command;

import net.ketone.drawingapp.matcher.RootCauseExceptionMatcher;
import net.ketone.drawingapp.receiver.ICanvas;
import org.junit.Rule;
import org.junit.Test;
import org.junit.contrib.java.lang.system.ExpectedSystemExit;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.omg.CORBA.SystemException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;

import static org.mockito.ArgumentMatchers.eq;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes=QuitCommand.class)
public class QuitCommandTest {

    @Autowired
    private ApplicationContext ctx;
	@Rule
    public ExpectedSystemExit exception = ExpectedSystemExit.none();

    @Test
    public void testSuccessfulExit() throws CommandException {
        exception.expectSystemExitWithStatus(0);
        Command command = ctx.getBean(QuitCommand.class, Arrays.asList("Q"));
        command.execute();
    }


}
