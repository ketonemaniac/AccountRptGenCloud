package net.ketone.drawingapp.cucumber;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/java/net/ketone/drawingapp/cucumber/feature",
                     glue = "net.ketone.drawingapp.cucumber.step")
public class CucumberTest {
}
