# Drawing Application
A simple console version of a drawing program

## Building/Testing
mvn clean package

## Running
Either 
- just start net.ketone.drawingapp.DrawingApplication in your IDE
- java -jar target\drawing-app-0.0.1-SNAPSHOT.jar